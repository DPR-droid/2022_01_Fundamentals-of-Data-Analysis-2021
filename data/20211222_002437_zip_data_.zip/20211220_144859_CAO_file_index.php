<!DOCTYPE html>
<!--[if IE 7]> <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width" />
  <meta name="description" content="The Central Applications Office (CAO) processes applications for undergraduate courses in Irish Higher Education Institutions." />
  
  <title>Central&nbsp;Applications&nbsp;Office</title>

  <link rel="stylesheet" href="include/foundation/css/normalize.css" />
  <link rel="stylesheet" href="include/foundation/css/foundation.min.css" />
  <link rel="stylesheet" href="include/cao14.css">
  <link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
  <link rel="apple-touch-icon-precomposed" sizes="57x57" href="icons/apple-touch-icon-57x57.png" />
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="icons/apple-touch-icon-114x114.png" />
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="icons/apple-touch-icon-72x72.png" />
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="icons/apple-touch-icon-144x144.png" />
  <link rel="apple-touch-icon-precomposed" sizes="60x60" href="icons/apple-touch-icon-60x60.png" />
  <link rel="apple-touch-icon-precomposed" sizes="120x120" href="icons/apple-touch-icon-120x120.png" />
  <link rel="apple-touch-icon-precomposed" sizes="76x76" href="icons/apple-touch-icon-76x76.png" />
  <link rel="apple-touch-icon-precomposed" sizes="152x152" href="icons/apple-touch-icon-152x152.png" />
  <link rel="icon" type="image/png" href="icons/favicon-196x196.png" sizes="196x196" />
  <link rel="icon" type="image/png" href="icons/favicon-96x96.png" sizes="96x96" />
  <link rel="icon" type="image/png" href="icons/favicon-32x32.png" sizes="32x32" />
  <link rel="icon" type="image/png" href="icons/favicon-16x16.png" sizes="16x16" />
  <link rel="icon" type="image/png" href="icons/favicon-128.png" sizes="128x128" />
  <meta name="application-name" content="Central&nbsp;Applications&nbsp;Office"/>
  <meta name="msapplication-TileColor" content="#FFFFFF" />
  <meta name="msapplication-TileImage" content="icons/mstile-144x144.png" />
  <meta name="msapplication-square70x70logo" content="icons/mstile-70x70.png" />
  <meta name="msapplication-square150x150logo" content="icons/mstile-150x150.png" />
  <meta name="msapplication-wide310x150logo" content="icons/mstile-310x150.png" />
  <meta name="msapplication-square310x310logo" content="icons/mstile-310x310.png" />
  <link rel="image_src" href="icons/fblogo.png">
  <script src="include/foundation/js/vendor/custom.modernizr.js"></script>  <script src="include/foundation/js/vendor/jquery.js"></script>
  <script>
  function SetCookie(c_name,value,expiredays)
  {
  var exdate=new Date()
		exdate.setDate(exdate.getDate()+expiredays)
		document.cookie=c_name+ "=" +escape(value)+"; SameSite=Strict; path=/"+((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
  }
  </script></head>
<body>

<div id="caoModal" class="reveal-modal"></div>

<div class="top-bar-div hide-for-print">
    <nav class="top-bar hide-for-1000plus">
      <ul class="title-area">
        <!-- Title Area -->
        <li class="name">
          <h1 class="long-title"><a href="#moremenu">Central&nbsp;Applications&nbsp;Office</a></h1>
		  <h1 class="short-title"><a href="#moremenu">CAO</a></h1>
        </li>
        <!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone -->
        <li class="toggle-topbar menu-icon"><a href="#"><span>Menu</span></a></li>
      </ul>

		<section class="top-bar-section">
		
		<!-- Right Nav Section -->
		<ul class="right"><li class="blue"><a href="http://www.cao.ie/index.php"><i class="fi-home"></i>&nbsp;Home</a></li>
<li class="red"><a href="https://www.cao.ie/apply.php?page=myapp"><i class="fi-star"></i>&nbsp;My Application</a></li>
<li class="green"><a href="https://www.cao.ie/apply.php"><i class="fi-clipboard-pencil"></i>&nbsp;Apply</a></li>
<li class="purple"><a href="http://www.cao.ie/courses.php"><i class="fi-page-search"></i>&nbsp;Courses</a></li>
<li class="orange"><a href="http://www.cao.ie/handbook.php"><i class="fi-book"></i>&nbsp;Handbook</a></li>
<li class="yellow"><a href="http://www.cao.ie/index.php?page=contact"><i class="fi-telephone"></i>&nbsp;Contact</a></li>		<li class="show-for-small"><a href="#moremenu"><i class="fi-list"></i>&nbsp;More...</a></li>
		</ul>
    </section>
	</nav>
  </div>
  <a href="#moremenu" id="morelink" class="morelink button secondary">&#9776;</a>
	<div class="row hide-for-1000plus">
    <div class="small-12 columns centre">
      <span id="logged-in-small"></span>      
		</div>
  </div><div class="eucookielaw hide-for-print" id="eucookielaw">
<div class="row">
<div class="large-10 columns eucookietext">
<b>Cookie Notice:</b>&nbsp;This site uses cookies to enable users to obtain the best experience from the website. In particular, secure encrypted cookies are necessary to allow secure progression through the various elements of the online 'apply' and 'my application' services. Session cookies are deleted automatically when the browser is closed. If you use the CAO interactive handbook or CAO Virtual Assistant, you will be asked to consent to third party cookies.<br><br>By continuing to use this site you are agreeing to our use of cookies. For more details please see our <a href="http://www2.cao.ie/privacy.php" target="_blank" title="Privacy Statement">privacy statement</a>. For more general information on cookies see <a href="http://www.aboutcookies.org/" target="_blank">http://www.aboutcookies.org/</a><br><br>
</div>
<div class="large-2 columns eucookietext">
<a class="button" id="removecookie">Hide Notice</a>
</div>
</div>
</div>
<script>
	if( document.cookie.indexOf("eucookie") ===-1 ){
		$("#eucookielaw").show();
	}	
    $("#removecookie").click(function () {
		SetCookie('eucookie','eucookie',365)
    $("#eucookielaw").remove();
    });
</script>
<div class="menu border-blue show-for-1000plus hide-for-print">
  <div class="row menu-bar">
	<ul class="button-group desktop-menu ">
	<li><img src="images/cao.png" alt="CAO logo" /></li><li class="blue"><a href="http://www.cao.ie/index.php"><i class="fi-home"></i>&nbsp;Home</a></li>
<li class="red"><a href="https://www.cao.ie/apply.php?page=myapp"><i class="fi-star"></i>&nbsp;My Application</a></li>
<li class="green"><a href="https://www.cao.ie/apply.php"><i class="fi-clipboard-pencil"></i>&nbsp;Apply</a></li>
<li class="purple"><a href="http://www.cao.ie/courses.php"><i class="fi-page-search"></i>&nbsp;Courses</a></li>
<li class="orange"><a href="http://www.cao.ie/handbook.php"><i class="fi-book"></i>&nbsp;Handbook</a></li>
<li class="yellow"><a href="http://www.cao.ie/index.php?page=contact"><i class="fi-telephone"></i>&nbsp;Contact</a></li>	</ul>
    </div>
	
<script>

var currenttime = 'Monday, 20 December 2021 15:05:17'
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=padlength(dayarray[serverdate.getDay()]+", "+serverdate.getDate())+" "+montharray[serverdate.getMonth()]+" "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())
document.getElementById("servertime").textContent=datestring+" "+timestring
}

function printpage(){
	alert('Please note that it is your responsibility to ensure your printer is in good working order.');
	window.print();
}

</script>

  <div class="row">

	<div class="large-3 columns server-time">
		<span id="servertime" class="smalltext">Monday, 20 December 2021 15:05</span>
	</div>
	
	<div class="large-6 columns centre">
		<span class="smalltext" id="logged-in"></span>
	</div>

	<div class="large-3 columns text-right">
		<span class="smalltext">
			<a href="http://www.cao.ie/index.php?ln=i">As Gaeilge</a>
			&nbsp;&nbsp;|&nbsp;&nbsp;
			<a href="javascript:printpage();">Print Page</a>
		</span>
	</div>

  </div>
  
	  </div>
  <!-- End Header and Nav -->
  
  
  <section class="mainandsidebar">
  
  <div class="row mainandsubmenu">	<div class="large-10 push-2 columns maincontent"><H3>Points Required for Entry to 2021 Courses</H3>

<B>Note:</B> points information will be displayed in a new window. To return to this page, simply close the new browser window.
<p></p>
<UL><UL><LI>
Click <a href="http://www2.cao.ie/points/CAOPointsCharts2021.xlsx" TARGET="_BLANK"><u>here</u></A> to see a spreadsheet of points data for <b>2021</b> courses.
<p></p>
</LI><LI>
Click <a href="http://www2.cao.ie/points/GraduateMedicine2021Round0.pdf" TARGET="_BLANK"><u>here</u></A> to see a list of the points required for entry to Graduate Medicine courses, <b>Round 0, 2021</b>.
<p></p>
</LI>
<LI>
Click <a href="http://www2.cao.ie/points/mat_nur_pts_rndA_2021.pdf" TARGET="_BLANK"><u>here</u></A> to see a list of the points required for entry to Mature Nursing courses, <b>Round A, 2021</b>.
<p></p>
</LI>

</UL>    </div>

	<div class="large-2 pull-10 columns hide-for-print ">
  	<ul class="side-nav"><li id="moremenu" class="show-for-small text-right"><a href="#"><i class="fi-arrow-up"></i> Top</a></li><li><a href="http://www.cao.ie/index.php?page=hei">Contact a HEI</a></li>
<li><a href="http://www.cao.ie/index.php?page=studentresources">Applicant Resources</a></li>
<li><a href="http://www.cao.ie/index.php?page=downloads">Downloads</a></li>
<li><a href="http://www.cao.ie/index.php?page=importantdates">Important Dates</a></li>
<li><a href="http://www.cao.ie/index.php?page=haq">Have a Question?</a></li>

<li class="divider"></li>

<li><a href="http://www.cao.ie/index.php?page=mature">Mature Applicants</a></li>
<li><a href="http://www.cao.ie/index.php?page=accessroutes">Access Routes<br>DARE / HEAR</a></li>
<li><a href="http://www.cao.ie/index.php?page=scoring&s=fetac">QQI FET/FETAC</a></li>
<li><a href="http://www.cao.ie/index.php?page=medentry">Entry to Medicine</a></li>
<li><a href="http://www.cao.ie/index.php?page=restrictions">Restrictions</a></li>
<li><a href="http://www.cao.ie/index.php?page=parents">Parents / Guardians</a></li>
<li><a href="http://www.cao.ie/index.php?page=schools">Guidance / Schools</a></li>
<li><a href="http://www.cao.ie/index.php?page=mediastats">Media and Statistics</a></li>

<li class="divider"></li>

<li><a href="http://www.cao.ie/index.php?page=weblinks">Useful Links</a></li>
<li><a href="http://www.cao.ie/index.php?page=contact">Contact Us</a></li>

<li class="show-for-small divider"></li>
<li class="show-for-small"><a href="http://www.cao.ie/index.php?ln=i">As Gaeilge</a></li>  	</ul>
	</div>

  </div>
  
  </section>  <!-- Footer -->
  
  <div class="footer-container border-blue hide-for-print">
  <footer class="row centre">
    <div class="twelve columns">
      <!-- <hr /> -->
      <div class="row"><script>

function openCopyright(URL) {
copyrightWindow=window.open(URL,"copyrightwindow","toolbar=no,width=650,height=420,status=no,scrollbars=yes,resize=yes,resizable=yes,menubar=no");
if (window.focus) { copyrightWindow.focus(); }
}

</script>


<div>
Central Applications Office Ltd. - Registered in Ireland Number 53983 - Registered Office: Tower House, Eglinton Street, Galway.
<br><br><a href="javascript:openCopyright('http://www2.cao.ie/copyright.php');">Copyright &copy; 2021</a> - All Rights Reserved - <a href="http://www2.cao.ie/privacy.php" target="_blank" title="Privacy Statement">CAO Privacy Statement</a>&nbsp;(b3)
<br><br><a href="http://www.cao.ie/index.php?page=aboutCAO"><u>About CAO</u></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.cao.ie/index.php?page=privacy"><u>Data Privacy</u></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.cao.ie/index.php?page=mediastats"><u>Media and Statistics</u></a>
</div>

      </div>
    </div> 
  </footer>
  </div>  <script src="include/foundation/js/vendor/jquery.js"></script>
  <script src="include/foundation/js/foundation.min.js"></script>
  <script>
    $(document).foundation();
  </script>
  <script src="include/js/onscroll.js"></script>
  <script>window.onscroll = function() {scrollFunction()};</script>
  <script>
	setInterval("displaytime()", 1000);
  </script>

</body>
</html>